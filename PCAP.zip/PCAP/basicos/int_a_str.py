trece = 13
unoypico = 1.3
str_trece = str(trece)
str_unoypico = str(unoypico)

print(str_trece + ' y ' + str_unoypico)
    