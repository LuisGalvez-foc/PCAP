si='13'
sf='1.3'
itg=int(si)
flt=float(sf)

print('suma :' , itg + flt)